# Assets de Reliquias — transferencia binaria

Fuente: `HIPERAUSTRALIS_COMPENDIOS_0.4.76_FAUNA_52_AUDITADA_LAB (3).zip`

Contiene exclusivamente los 16 WebP de Reliquias (8 legendarias y 8 cotidianas), extraídos sin transformación. Los nombres y bytes se conservan. Resolución declarada por auditoría: 512×512, RGB, sin alfa.

Las carpetas `legendarias/` y `cotidianas/` son organización del paquete de transferencia; no representan carpetas Foundry.
