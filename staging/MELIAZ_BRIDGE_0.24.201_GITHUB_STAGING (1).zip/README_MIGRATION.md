# MELIAZ Bridge 0.24.201 — staging para GitHub

Este paquete conserva íntegramente el contenido del ZIP de origen y lo sitúa bajo
`module/meliaz-bridge/` para su incorporación a una rama aislada.

## Procedencia
- Archivo de origen: `MELIAZ_BRIDGE_0.24.201_KONA_LEGACY_WRAPPERS_V14.zip`
- Versión declarada del módulo: `0.24.201`
- Foundry mínimo declarado: V14
- Dependencia declarada: Custom System Builder >= 6.0.0
- Archivos originales conservados: 167
- No incluye exportaciones de actores ni fixtures locales de QA.

## Integridad
El manifiesto `MELIAZ_BRIDGE_0.24.201_GITHUB_STAGING_MANIFEST.json` registra
tamaño y SHA-256 de cada archivo original, con su ruta de destino en GitHub.
No se modificó el contenido de los archivos del módulo.

## Estructura de destino
`module/meliaz-bridge/<contenido original del módulo>`

## Estado de validación
- Integridad del ZIP original: PASS
- Sintaxis de `bridge.js`: PASS
- Sintaxis de `kona-token-icons.js`: PASS
- Instalación y ejecución en Foundry V14 + CSB 6.x: PENDIENTE
- Revisión de rutas tras reubicación en GitHub: PENDIENTE
- Integración en `main`: NO AUTORIZADA / NO REALIZADA

No mezclar con `hiperaustralis-compendios-prototype` ni con `hiperaustralis-rituales`.
No subir actores de prueba (incluido `01 MONO`).
